<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();


	//Add column
	$fields = array(
        'package_type' => array('type' => 'INT', 'null'  => FALSE, 'constraint' => '11', 'default' => 0)
	);
	$this->dbforge->add_column('package', $fields);

	//Add column
	$fields = array(
        'number_of_listings' => array('type' => 'INT', 'null'  => FALSE, 'constraint' => '11', 'default' => 0)
	);
	$this->dbforge->add_column('package', $fields);

	//Add column
	$fields = array(
        'featured' => array('type' => 'INT', 'null'  => FALSE, 'constraint' => '11', 'default' => 0)
	);
	$this->dbforge->add_column('package', $fields);

	//Add column
	$fields = array(
        'is_featured' => array('type' => 'INT', 'null'  => FALSE, 'constraint' => '11', 'default' => 0)
	);
	$this->dbforge->add_column('listing', $fields);


	// Drop column
	$this->dbforge->drop_column('review', 'reviewer_email');

	// Modifying a message_thread table column
	$fields = array(
        'reviewer' => array(
                'name' => 'reviewer_id',
                'type' => 'INT',
				'null' => TRUE,
				'constraint' => '11'
        ),
	);
	$this->dbforge->modify_column('review', $fields);


	// insert data on settings table
	$settings_data = array( 'description' => '1.1' );
	$CI->db->where('type', 'version');
	$CI->db->update('settings', $settings_data);
?>
